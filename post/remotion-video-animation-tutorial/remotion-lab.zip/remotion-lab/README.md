# remotion-lab

《用程式碼做影片動畫：Remotion 從零開始》這篇文章用的範例專案。
文章裡的片頭動畫、字卡動畫、封面圖，都是從這裡算出來的。

文章出處：https://wellstsai.com/post/remotion-video-animation-tutorial/

## 跑起來

需要 Node.js 18 以上。

```bash
npm i
npm run dev
```

瀏覽器打開 `localhost:3000`，左邊會列出這個專案裡的所有影片。

## 目錄

```
src/
  Root.tsx        註冊這個專案有哪幾支影片，改文案、改長度都在這裡
  Intro.tsx       文章開頭那支流程動畫
  TitleCards.tsx  三張字卡的動畫，文章的主要範例
  Cover.tsx       封面圖
  Showcase.tsx    各種繪圖套件的展示
  demos/          GSAP、D3、Lottie、Three.js、Canvas 的個別範例
                  SunnyBars.tsx 是丟一句提示詞給 AI 代理產出來的
public/           圖片、音檔放這裡，程式裡用 staticFile() 取用
.agents/skills/   官方技能文件，AI 代理會自己讀
remotion.config.ts  輸出設定（像素格式、色彩空間那些）
scripts/
  make-music.mjs  產生片頭的背景音樂，純合成
```

## 輸出

```bash
# 一般 mp4
npx remotion render TitleCards out/titlecards.mp4

# 透明背景，拉進剪輯軟體疊在螢幕錄影上
npx remotion render TitleCardsAlpha out/overlay.mov \
  --codec=prores --prores-profile=4444 \
  --image-format=png --pixel-format=yuva444p10le
```

片頭那支 `Intro` 需要背景音樂，先產生再算圖：

```bash
node scripts/make-music.mjs 61.9 public/ambient.wav
npx remotion render Intro out/intro.mp4
```

## 授權

Remotion 本身用的是 Remotion License，個人與 3 人以下公司免費，
4 人以上要買 Company License：https://www.remotion.pro/license
