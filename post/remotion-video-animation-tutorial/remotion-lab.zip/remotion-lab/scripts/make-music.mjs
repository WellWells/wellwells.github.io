// Intro 的背景音樂：C 大調、100 BPM，襯底 + 撥弦分解和弦 + 低音 + 沙鈴。
// 全部是合成出來的，沒有取樣素材。用法：node scripts/make-music.mjs <秒數> <輸出路徑>
import { writeFileSync } from "node:fs";

const SR = 44100;
const seconds = Number(process.argv[2] ?? 62);
const outPath = process.argv[3] ?? "public/ambient.wav";
const N = Math.round(SR * seconds);

const BPM = 100;
const BEAT = 60 / BPM; // 0.6 秒
const BAR = BEAT * 4; // 2.4 秒
const CHORD_LEN = BAR * 2; // 一個和弦兩小節
const EIGHTH = BEAT / 2;

// C - G - Am - F，最常見的大調進行，聽起來是開的
const CHORDS = [
  { root: 130.81, pad: [130.81, 164.81, 196.0, 261.63], arp: [523.25, 659.25, 783.99, 659.25] }, // C
  { root: 98.0, pad: [98.0, 123.47, 146.83, 196.0], arp: [493.88, 587.33, 783.99, 587.33] }, // G
  { root: 110.0, pad: [110.0, 130.81, 164.81, 220.0], arp: [523.25, 659.25, 880.0, 659.25] }, // Am
  { root: 87.31, pad: [87.31, 110.0, 130.81, 174.61], arp: [523.25, 698.46, 880.0, 698.46] }, // F
];

const left = new Float64Array(N);
const right = new Float64Array(N);

const chordAt = (t) => CHORDS[Math.floor(t / CHORD_LEN) % CHORDS.length];

// 襯底：柔和的長音，音量壓低當底
const padVoice = (t, f, phase) => {
  const w = 2 * Math.PI * f * t + phase;
  return Math.sin(w) + 0.3 * Math.sin(2 * w) + 0.1 * Math.sin(3 * w);
};

const chordCount = Math.ceil(seconds / CHORD_LEN) + 1;
for (let c = 0; c < chordCount; c++) {
  const chord = CHORDS[c % CHORDS.length];
  const start = c * CHORD_LEN;
  const fade = 0.9;
  const from = Math.max(0, Math.floor((start - fade) * SR));
  const to = Math.min(N, Math.ceil((start + CHORD_LEN + fade) * SR));

  for (let i = from; i < to; i++) {
    const t = i / SR;
    const local = t - start;
    let env;
    if (local < fade) env = 0.5 - 0.5 * Math.cos((Math.PI * (local + fade)) / (2 * fade));
    else if (local > CHORD_LEN - fade)
      env = 0.5 + 0.5 * Math.cos((Math.PI * (local - (CHORD_LEN - fade))) / (2 * fade));
    else env = 1;
    if (env <= 0) continue;

    let l = 0;
    let r = 0;
    for (let n = 0; n < chord.pad.length; n++) {
      const f = chord.pad[n];
      const gain = 0.5 / (1 + n * 0.5);
      l += gain * padVoice(t, f * 0.999, n * 1.7);
      r += gain * padVoice(t, f * 1.001, n * 2.3);
    }
    left[i] += l * env;
    right[i] += r * env;
  }
}

// 撥弦：八分音符的分解和弦，快起音、短衰減，這是「亮」的來源
const plucks = Math.ceil(seconds / EIGHTH);
for (let k = 0; k < plucks; k++) {
  const start = k * EIGHTH;
  const chord = chordAt(start);
  const f = chord.arp[k % chord.arp.length];
  // 每小節的最後一個八分音符跳過，留一點呼吸
  if (k % 8 === 7) continue;
  const dur = 0.55;
  const from = Math.floor(start * SR);
  const to = Math.min(N, Math.ceil((start + dur) * SR));
  const pan = k % 2 === 0 ? [1.0, 0.75] : [0.75, 1.0];
  for (let i = from; i < to; i++) {
    const local = i / SR - start;
    const decay = Math.exp(-local * 7.5);
    const w = 2 * Math.PI * f * local;
    const s =
      (Math.sin(w) + 0.45 * Math.sin(2 * w) + 0.2 * Math.sin(3 * w) + 0.08 * Math.sin(5 * w)) *
      decay *
      0.5;
    left[i] += s * pan[0];
    right[i] += s * pan[1];
  }
}

// 低音：每小節的第一、三拍
for (let b = 0; b * BEAT < seconds; b++) {
  if (b % 2 !== 0) continue;
  const start = b * BEAT;
  const f = chordAt(start).root / 2;
  const dur = 0.7;
  const from = Math.floor(start * SR);
  const to = Math.min(N, Math.ceil((start + dur) * SR));
  for (let i = from; i < to; i++) {
    const local = i / SR - start;
    const decay = Math.exp(-local * 4.5);
    const s = (Math.sin(2 * Math.PI * f * local) + 0.25 * Math.sin(4 * Math.PI * f * local)) * decay * 0.85;
    left[i] += s;
    right[i] += s;
  }
}

// 沙鈴：反拍上很小聲的雜訊，給一點律動
let noiseSeed = 12345;
const noise = () => {
  noiseSeed = (noiseSeed * 1103515245 + 12345) & 0x7fffffff;
  return (noiseSeed / 0x7fffffff) * 2 - 1;
};
for (let k = 0; k < plucks; k++) {
  if (k % 2 === 0) continue;
  const start = k * EIGHTH;
  const dur = 0.09;
  const from = Math.floor(start * SR);
  const to = Math.min(N, Math.ceil((start + dur) * SR));
  let prev = 0;
  for (let i = from; i < to; i++) {
    const local = i / SR - start;
    const decay = Math.exp(-local * 42);
    const x = noise();
    const hp = x - prev; // 一階高通，聽起來才像沙鈴不像雜音
    prev = x;
    left[i] += hp * decay * 0.11;
    right[i] += hp * decay * 0.11;
  }
}

// 很輕的低通，只磨掉最刺的部分，保持明亮
const lowpass = (buf, a) => {
  let y = 0;
  for (let i = 0; i < buf.length; i++) {
    y += a * (buf[i] - y);
    buf[i] = y;
  }
};
lowpass(left, 0.42);
lowpass(right, 0.42);

let peak = 0;
for (let i = 0; i < N; i++) peak = Math.max(peak, Math.abs(left[i]), Math.abs(right[i]));
const norm = peak > 0 ? 0.62 / peak : 1;
const fadeIn = 1.6 * SR;
const fadeOut = 3.0 * SR;

const data = Buffer.alloc(N * 4);
for (let i = 0; i < N; i++) {
  let g = norm;
  if (i < fadeIn) g *= i / fadeIn;
  if (i > N - fadeOut) g *= (N - i) / fadeOut;
  data.writeInt16LE(Math.round(Math.max(-1, Math.min(1, left[i] * g)) * 32767), i * 4);
  data.writeInt16LE(Math.round(Math.max(-1, Math.min(1, right[i] * g)) * 32767), i * 4 + 2);
}

const header = Buffer.alloc(44);
header.write("RIFF", 0);
header.writeUInt32LE(36 + data.length, 4);
header.write("WAVE", 8);
header.write("fmt ", 12);
header.writeUInt32LE(16, 16);
header.writeUInt16LE(1, 20);
header.writeUInt16LE(2, 22);
header.writeUInt32LE(SR, 24);
header.writeUInt32LE(SR * 4, 28);
header.writeUInt16LE(4, 32);
header.writeUInt16LE(16, 34);
header.write("data", 36);
header.writeUInt32LE(data.length, 40);

writeFileSync(outPath, Buffer.concat([header, data]));
console.log(`${outPath}  ${seconds}s  ${((header.length + data.length) / 1e6).toFixed(2)} MB`);
