import React from "react";
import {
  AbsoluteFill,
  interpolate,
  spring,
  useCurrentFrame,
  useVideoConfig,
} from "remotion";

export const SUNNY_BARS_DURATION = 90;

const FONT = '"Noto Sans CJK TC", system-ui, sans-serif';

// 明亮溫暖的色系：珊瑚紅 → 橘 → 琥珀 → 陽光黃 → 淺黃
const BARS = [
  { height: 380, color: "#FF5E62" },
  { height: 620, color: "#FF8C42" },
  { height: 470, color: "#FFB627" },
  { height: 760, color: "#FFD93D" },
  { height: 560, color: "#FFF07C" },
];

const BAR_WIDTH = 140;
const BAR_GAP = 60;
const DOT_SIZE = 46;
const DOT_OFFSET = 20; // 圓點跟長條頂端的距離
const STAGGER = 6; // 每根長條差 6 幀出場
const FLOAT_FROM = 54; // 最後一根彈到定位之後才開始浮動

export const SunnyBars: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  // 整排一起輕輕上下浮動，振幅淡入，避免跟彈跳的收尾銜接時跳一下
  const floatAmount = interpolate(frame, [FLOAT_FROM, FLOAT_FROM + 14], [0, 14], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });

  return (
    <AbsoluteFill
      style={{
        background: "radial-gradient(circle at 50% 18%, #43241a 0%, #1b0f09 72%)",
        fontFamily: FONT,
        justifyContent: "center",
        alignItems: "center",
      }}
    >
      <div
        style={{
          display: "flex",
          alignItems: "flex-end",
          gap: BAR_GAP,
          height: 860,
          translate: `0px ${Math.sin((frame - FLOAT_FROM) / 9) * floatAmount}px`,
        }}
      >
        {BARS.map((bar, i) => {
          // spring 的過衝就是彈跳感，damping 調低一點才會 Q
          const rise = spring({
            frame: frame - i * STAGGER,
            fps,
            config: { damping: 11, stiffness: 130, mass: 0.85 },
          });

          return (
            <div
              key={bar.color}
              style={{
                position: "relative",
                width: BAR_WIDTH,
                height: bar.height * rise,
                borderRadius: BAR_WIDTH / 2,
                background: bar.color,
                boxShadow: `0 0 60px ${bar.color}44`,
              }}
            >
              <div
                style={{
                  position: "absolute",
                  bottom: "100%",
                  left: "50%",
                  marginBottom: DOT_OFFSET,
                  width: DOT_SIZE,
                  height: DOT_SIZE,
                  borderRadius: "50%",
                  background: bar.color,
                  boxShadow: `0 0 40px ${bar.color}66`,
                  translate: "-50% 0px",
                  scale: rise,
                }}
              />
            </div>
          );
        })}
      </div>
    </AbsoluteFill>
  );
};
