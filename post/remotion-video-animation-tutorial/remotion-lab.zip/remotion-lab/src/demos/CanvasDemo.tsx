import React, { useLayoutEffect, useRef } from "react";
import { AbsoluteFill, useCurrentFrame, useVideoConfig } from "remotion";

// Canvas 類的套件（p5.js、Fabric.js）本質上都是這件事：
// 每一幀把畫布清掉，依照 frame 重畫一次。不要讓它自己跑動畫迴圈。
export const CanvasDemo: React.FC = () => {
  const frame = useCurrentFrame();
  const { width, height } = useVideoConfig();
  const ref = useRef<HTMLCanvasElement>(null);

  useLayoutEffect(() => {
    const ctx = ref.current?.getContext("2d");
    if (!ctx) return;

    ctx.clearRect(0, 0, width, height);
    ctx.fillStyle = "#0b1220";
    ctx.fillRect(0, 0, width, height);

    const cx = width / 2;
    const cy = height / 2;

    for (let i = 0; i < 140; i++) {
      // 用 i 當種子，不要用 Math.random()，否則每一幀都會不一樣
      const angle = (i / 140) * Math.PI * 2 + frame * 0.012;
      const wobble = Math.sin(frame * 0.05 + i * 0.35) * 90;
      const radius = 260 + wobble;

      const x = cx + Math.cos(angle) * radius;
      const y = cy + Math.sin(angle) * radius * 0.55;
      const size = 3 + ((i % 7) + 1) * 1.4;

      ctx.beginPath();
      ctx.arc(x, y, size, 0, Math.PI * 2);
      ctx.fillStyle = i % 3 === 0 ? "#38bdf8" : "rgba(99, 102, 241, 0.75)";
      ctx.fill();
    }
  }, [frame, width, height]);

  return (
    <AbsoluteFill style={{ background: "#0b1220" }}>
      <canvas ref={ref} width={width} height={height} />
    </AbsoluteFill>
  );
};
