import React, { useEffect, useState } from "react";
import { Lottie, LottieAnimationData } from "@remotion/lottie";
import {
  AbsoluteFill,
  cancelRender,
  continueRender,
  delayRender,
  staticFile,
} from "remotion";

const FONT = '"Noto Sans CJK TC", system-ui, sans-serif';

export const LottieDemo: React.FC<{ caption?: string }> = ({
  caption = "Lottie 播放中",
}) => {
  // 檔案是非同步讀的，要先把算圖擋住，載完再放行
  const [handle] = useState(() => delayRender("Loading Lottie animation"));
  const [animationData, setAnimationData] = useState<LottieAnimationData | null>(
    null,
  );

  useEffect(() => {
    fetch(staticFile("pulse.json"))
      .then((res) => res.json())
      .then((json) => {
        setAnimationData(json);
        continueRender(handle);
      })
      .catch((err) => cancelRender(err));
  }, [handle]);

  return (
    <AbsoluteFill
      style={{
        background: "#0b1220",
        fontFamily: FONT,
        justifyContent: "center",
        alignItems: "center",
        gap: 40,
      }}
    >
      {animationData ? (
        <Lottie animationData={animationData} loop style={{ width: 420, height: 420 }} />
      ) : null}
      <div style={{ fontSize: 44, color: "#94a3b8" }}>{caption}</div>
    </AbsoluteFill>
  );
};
