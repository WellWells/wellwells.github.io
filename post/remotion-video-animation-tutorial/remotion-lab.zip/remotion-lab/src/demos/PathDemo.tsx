import React from "react";
import { evolvePath, getPointAtLength, getLength } from "@remotion/paths";
import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";

const FONT = '"Noto Sans CJK TC", system-ui, sans-serif';

// 這條線就是「軌跡」。實務上可以先在圖上把路徑畫出來，再叫 AI 轉成 d 屬性
const PATH =
  "M 160 520 C 360 220, 620 760, 860 420 S 1300 180, 1560 460";

const W = 1720;
const H = 760;

export const PathDemo: React.FC = () => {
  const frame = useCurrentFrame();

  const progress = interpolate(frame, [0, 110], [0, 1], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });

  // 讓線條像被畫出來一樣
  const { strokeDasharray, strokeDashoffset } = evolvePath(progress, PATH);

  // 沿著同一條線移動的點
  const total = getLength(PATH);
  // getPointAtLength 在路徑為空時會回 null，這裡給個保底值
  const point = getPointAtLength(PATH, total * progress) ?? { x: 0, y: 0 };

  return (
    <AbsoluteFill
      style={{
        background: "#0b1220",
        fontFamily: FONT,
        justifyContent: "center",
        alignItems: "center",
      }}
    >
      <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`}>
        <path d={PATH} stroke="rgba(255,255,255,0.10)" strokeWidth={6} fill="none" />
        <path
          d={PATH}
          stroke="#38bdf8"
          strokeWidth={6}
          fill="none"
          strokeLinecap="round"
          strokeDasharray={strokeDasharray}
          strokeDashoffset={strokeDashoffset}
        />
        <circle cx={point.x} cy={point.y} r={26} fill="#38bdf8" />
        <circle cx={point.x} cy={point.y} r={44} fill="none" stroke="#38bdf8" strokeWidth={3} opacity={0.4} />
      </svg>
    </AbsoluteFill>
  );
};
