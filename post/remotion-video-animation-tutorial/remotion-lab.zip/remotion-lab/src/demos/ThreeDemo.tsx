import React from "react";
import { ThreeCanvas } from "@remotion/three";
import { AbsoluteFill, interpolate, useCurrentFrame, useVideoConfig } from "remotion";

export const ThreeDemo: React.FC = () => {
  const frame = useCurrentFrame();
  const { width, height } = useVideoConfig();

  // 所有動畫都要由 frame 推，不能用 useFrame()，否則算圖會閃爍
  const rotationY = frame * 0.025;
  const rotationX = Math.sin(frame * 0.02) * 0.35;
  const lift = interpolate(frame, [0, 40], [-3, 0], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });

  return (
    <AbsoluteFill style={{ background: "#0b1220" }}>
      <ThreeCanvas width={width} height={height} camera={{ position: [0, 0, 8], fov: 50 }}>
        <ambientLight intensity={0.5} />
        <directionalLight position={[5, 6, 5]} intensity={1.1} />
        <pointLight position={[-5, -3, 2]} intensity={0.6} color="#38bdf8" />

        <mesh rotation={[rotationX, rotationY, 0]} position={[0, lift, 0]}>
          <torusKnotGeometry args={[1.5, 0.5, 160, 24]} />
          <meshStandardMaterial color="#38bdf8" roughness={0.25} metalness={0.7} />
        </mesh>
      </ThreeCanvas>
    </AbsoluteFill>
  );
};
