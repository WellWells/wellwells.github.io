import React from "react";
import { useGsapTimeline } from "@remotion/gsap";
import { AbsoluteFill } from "remotion";

const FONT = '"Noto Sans CJK TC", system-ui, sans-serif';

export const GsapDemo: React.FC<{ title?: string }> = ({
  title = "GSAP 時間軸",
}) => {
  // build 只跑一次，時間軸是暫停的，Remotion 依照目前的幀去 seek
  const scope = useGsapTimeline<HTMLDivElement>(({ timeline, selector }) => {
    timeline
      .from(selector("[data-title]"), {
        y: 60,
        opacity: 0,
        duration: 0.7,
        ease: "power3.out",
      })
      .from(
        selector("[data-bar]"),
        {
          scaleX: 0,
          transformOrigin: "left center",
          duration: 0.6,
          ease: "power2.out",
          stagger: 0.15,
        },
        "-=0.2",
      )
      .to(selector("[data-dot]"), {
        rotation: 360,
        duration: 1.5,
        ease: "none",
      });
  });

  return (
    <AbsoluteFill
      ref={scope}
      style={{
        background: "#0b1220",
        fontFamily: FONT,
        justifyContent: "center",
        padding: 140,
      }}
    >
      <div
        style={{ display: "flex", alignItems: "center", gap: 24, marginBottom: 48 }}
      >
        <div
          data-dot
          style={{
            width: 56,
            height: 56,
            background: "#38bdf8",
            borderRadius: 12,
          }}
        />
        <div data-title style={{ fontSize: 64, fontWeight: 700, color: "#f8fafc" }}>
          {title}
        </div>
      </div>

      {[80, 62, 44].map((w, i) => (
        <div
          key={i}
          data-bar
          style={{
            height: 46,
            width: `${w}%`,
            marginBottom: 20,
            borderRadius: 10,
            background: `linear-gradient(90deg, #38bdf8, #6366f1)`,
          }}
        />
      ))}
    </AbsoluteFill>
  );
};
