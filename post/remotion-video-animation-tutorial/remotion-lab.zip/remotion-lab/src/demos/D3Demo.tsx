import React from "react";
import { scaleLinear, scaleBand } from "d3-scale";
import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";

const FONT = '"Noto Sans CJK TC", system-ui, sans-serif';

// 假資料：某個頻道六個月的訂閱數
const VALUES = [1200, 2100, 1800, 3400, 4600, 6100];

const W = 1400;
const H = 620;
const PAD = { top: 40, right: 40, bottom: 70, left: 110 };

export const D3Demo: React.FC<{ months?: string[] }> = ({
  months = ["3 月", "4 月", "5 月", "6 月", "7 月", "8 月"],
}) => {
  const frame = useCurrentFrame();
  const DATA = VALUES.map((value, i) => ({ month: months[i], value }));

  // d3 只拿來算比例尺，畫圖還是交給 React，這樣才能逐幀重算
  const x = scaleBand()
    .domain(DATA.map((d) => d.month))
    .range([PAD.left, W - PAD.right])
    .padding(0.35);

  const y = scaleLinear()
    .domain([0, Math.max(...DATA.map((d) => d.value))])
    .range([H - PAD.bottom, PAD.top]);

  return (
    <AbsoluteFill
      style={{
        background: "#0b1220",
        fontFamily: FONT,
        justifyContent: "center",
        alignItems: "center",
      }}
    >
      <svg width={W} height={H}>
        {/* 橫向格線 */}
        {y.ticks(5).map((t) => (
          <g key={t}>
            <line
              x1={PAD.left}
              x2={W - PAD.right}
              y1={y(t)}
              y2={y(t)}
              stroke="rgba(255,255,255,0.08)"
            />
            <text x={PAD.left - 16} y={y(t) + 6} fill="#64748b" fontSize={20} textAnchor="end">
              {t}
            </text>
          </g>
        ))}

        {DATA.map((d, i) => {
          // 每根柱子晚 6 幀長出來
          const grow = interpolate(frame, [i * 6, i * 6 + 24], [0, 1], {
            extrapolateLeft: "clamp",
            extrapolateRight: "clamp",
          });
          const full = H - PAD.bottom - y(d.value);
          const h = full * grow;

          return (
            <g key={d.month}>
              <rect
                x={x(d.month)}
                y={H - PAD.bottom - h}
                width={x.bandwidth()}
                height={h}
                rx={8}
                fill="#38bdf8"
              />
              <text
                x={(x(d.month) ?? 0) + x.bandwidth() / 2}
                y={H - PAD.bottom + 34}
                fill="#94a3b8"
                fontSize={22}
                textAnchor="middle"
              >
                {d.month}
              </text>
            </g>
          );
        })}
      </svg>
    </AbsoluteFill>
  );
};
