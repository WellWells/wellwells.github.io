import React from "react";
import {
  AbsoluteFill,
  Html5Audio,
  Sequence,
  interpolate,
  spring,
  useCurrentFrame,
  useVideoConfig,
} from "remotion";
import { whip } from "@remotion/sfx";

export type Card = {
  no: string;
  title: string;
  body: string;
};

export type TitleCardsProps = {
  heading: string;
  cards: Card[];
  transparent: boolean;
  sound: boolean;
};

const FONT = '"Noto Sans CJK TC", "Noto Sans TC", system-ui, sans-serif';
const ACCENT = "#38bdf8";

// 每張卡片間隔 24 幀出現，第一張從第 20 幀開始
const FIRST_CARD = 20;
const STAGGER = 24;

const OneCard: React.FC<{ card: Card; sound: boolean; solid: boolean }> = ({
  card,
  sound,
  solid,
}) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  // spring 產生 0 到 1 的彈跳值，用來推位移與縮放
  const entrance = spring({
    frame,
    fps,
    config: { damping: 14, mass: 0.6 },
  });

  const translateX = interpolate(entrance, [0, 1], [-80, 0]);
  const opacity = interpolate(entrance, [0, 1], [0, 1]);

  return (
    <div
      style={{
        display: "flex",
        alignItems: "center",
        gap: 32,
        padding: "28px 40px",
        borderRadius: 20,
        // 透明背景輸出時卡片要自己不透明，不然字會直接疊在下層影片上
        background: solid ? "rgba(11, 18, 32, 0.92)" : "rgba(255, 255, 255, 0.04)",
        border: "1px solid rgba(255, 255, 255, 0.10)",
        borderLeft: `6px solid ${ACCENT}`,
        opacity,
        transform: `translateX(${translateX}px)`,
      }}
    >
      <div
        style={{
          flexShrink: 0,
          width: 72,
          height: 72,
          borderRadius: "50%",
          background: ACCENT,
          color: "#0b1220",
          fontSize: 40,
          fontWeight: 700,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        {card.no}
      </div>
      {sound ? <Html5Audio src={whip} volume={0.4} /> : null}
      <div>
        <div style={{ fontSize: 46, fontWeight: 700, color: "#f8fafc" }}>
          {card.title}
        </div>
        <div style={{ fontSize: 28, color: "#94a3b8", marginTop: 8 }}>
          {card.body}
        </div>
      </div>
    </div>
  );
};

export const TitleCards: React.FC<TitleCardsProps> = ({
  heading,
  cards,
  transparent,
  sound,
}) => {
  const frame = useCurrentFrame();
  const { durationInFrames } = useVideoConfig();

  // 最後 20 幀整體淡出，留給剪輯軟體當轉場
  const fadeOut = interpolate(
    frame,
    [durationInFrames - 20, durationInFrames],
    [1, 0],
    { extrapolateLeft: "clamp", extrapolateRight: "clamp" },
  );

  const headingOpacity = interpolate(frame, [0, 15], [0, 1], {
    extrapolateRight: "clamp",
  });

  return (
    <AbsoluteFill
      style={{
        background: transparent ? "transparent" : "#0b1220",
        fontFamily: FONT,
        justifyContent: "center",
        padding: 120,
        opacity: fadeOut,
      }}
    >
      {/* 透明背景輸出時不放標題，白字疊在別人的影片上會看不到 */}
      {transparent ? null : (
        <div
          style={{
            fontSize: 64,
            fontWeight: 700,
            color: "#f8fafc",
            marginBottom: 48,
            opacity: headingOpacity,
          }}
        >
          {heading}
        </div>
      )}

      <div style={{ display: "flex", flexDirection: "column", gap: 24 }}>
        {cards.map((card, i) => (
          <Sequence key={card.no} from={FIRST_CARD + i * STAGGER} layout="none">
            <OneCard card={card} sound={sound} solid={transparent} />
          </Sequence>
        ))}
      </div>
    </AbsoluteFill>
  );
};
