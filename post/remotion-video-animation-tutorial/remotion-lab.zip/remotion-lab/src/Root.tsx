import "./index.css";
import { Composition } from "remotion";
import { TitleCards, TitleCardsProps } from "./TitleCards";
import { Cover, CoverProps } from "./Cover";
import { GsapDemo } from "./demos/GsapDemo";
import { D3Demo } from "./demos/D3Demo";
import { LottieDemo } from "./demos/LottieDemo";
import { ThreeDemo } from "./demos/ThreeDemo";
import { PathDemo } from "./demos/PathDemo";
import { CanvasDemo } from "./demos/CanvasDemo";
import { Showcase, SHOWCASE_DURATION } from "./Showcase";
import { Intro, INTRO_DURATION } from "./Intro";
import { SunnyBars, SUNNY_BARS_DURATION } from "./demos/SunnyBars";

const SHOWCASE_ZH = ["Remotion + GSAP", "Remotion + D3.js", "Remotion + Lottie", "Remotion + Three.js", "Remotion + @remotion/paths", "Remotion + Canvas"];
const SHOWCASE_EN = ["Remotion + GSAP", "Remotion + D3.js", "Remotion + Lottie", "Remotion + Three.js", "Remotion + @remotion/paths", "Remotion + Canvas"];

const ZH: TitleCardsProps = {
  heading: "用 Remotion 做影片要注意三件事",
  cards: [
    { no: "1", title: "不要過度動畫", body: "畫面一直閃，觀眾會看到不舒服" },
    { no: "2", title: "不要圖文不符", body: "動畫對不上旁白，就失去做動畫的意義" },
    { no: "3", title: "風格要一致", body: "用色、排版、速度統一，才會像同一個頻道" },
  ],
  transparent: false,
  sound: true,
};

const EN: TitleCardsProps = {
  heading: "Three things to watch when animating with Remotion",
  cards: [
    { no: "1", title: "Don't over-animate", body: "Constant motion wears the viewer out" },
    { no: "2", title: "Keep text and visuals in sync", body: "If they drift apart, the animation is pointless" },
    { no: "3", title: "Hold one style", body: "Same colours, spacing and pacing every time" },
  ],
  transparent: false,
  sound: true,
};


const CODE_ZH = [
  "// 用程式碼描述畫面，Remotion 逐幀算圖",
  "const frame = useCurrentFrame();",
  "",
  "const x = interpolate(",
  "  frame, [0, 30], [-80, 0]",
  ");",
  "",
  "<div style={{",
  "  transform: `translateX(${x}px)`",
  "}} />",
];

const CODE_EN = ["// Describe the frame in code, Remotion renders it", ...CODE_ZH.slice(1)];

const COVER_ZH: CoverProps = {
  title: "用程式碼做影片動畫",
  subtitle: "從安裝到輸出透明背景字卡",
  code: CODE_ZH,
};

const COVER2_ZH: CoverProps = {
  title: "一句 prompt 做不出好動畫",
  subtitle: "Skills 與五種繪圖套件實測",
  code: [
    "// 先把官方技能裝進專案",
    "npx remotion skills add",
    "",
    "// AI 才知道這個版本的",
    "// API 長什麼樣子",
    "$ ls .agents/skills/",
    "remotion-render",
    "remotion-markup ...",
  ],
};

const COVER2_EN: CoverProps = {
  title: "One prompt is not enough",
  subtitle: "Skills, and five drawing libraries tested",
  code: [
    "// Install the official skills first",
    "npx remotion skills add",
    "",
    "// so the agent knows what this",
    "// version's API looks like",
    "$ ls .agents/skills/",
    "remotion-render",
    "remotion-markup ...",
  ],
};

const COVER_EN: CoverProps = {
  title: "Animate video with code",
  subtitle: "From install to transparent title cards",
  code: CODE_EN,
};

export const RemotionRoot: React.FC = () => {
  return (
    <>
      <Composition
        id="TitleCards"
        component={TitleCards}
        durationInFrames={180}
        fps={30}
        width={1920}
        height={1080}
        defaultProps={ZH}
      />
      <Composition
        id="TitleCardsEn"
        component={TitleCards}
        durationInFrames={180}
        fps={30}
        width={1920}
        height={1080}
        defaultProps={EN}
      />
      <Composition
        id="TitleCardsAlpha"
        component={TitleCards}
        durationInFrames={180}
        fps={30}
        width={1920}
        height={1080}
        defaultProps={{ ...ZH, transparent: true, sound: false }}
      />
      <Composition
        id="Cover"
        component={Cover}
        durationInFrames={1}
        fps={30}
        width={1600}
        height={900}
        defaultProps={COVER_ZH}
      />
      <Composition id="Cover2" component={Cover} durationInFrames={1} fps={30} width={1600} height={900} defaultProps={COVER2_ZH} />
      <Composition id="Cover2En" component={Cover} durationInFrames={1} fps={30} width={1600} height={900} defaultProps={COVER2_EN} />
      <Composition
        id="CoverEn"
        component={Cover}
        durationInFrames={1}
        fps={30}
        width={1600}
        height={900}
        defaultProps={COVER_EN}
      />
      <Composition id="GsapDemo" component={GsapDemo} durationInFrames={120} fps={30} width={1920} height={1080} />
      <Composition id="D3Demo" component={D3Demo} durationInFrames={120} fps={30} width={1920} height={1080} />
      <Composition id="LottieDemo" component={LottieDemo} durationInFrames={120} fps={30} width={1920} height={1080} />
      <Composition id="ThreeDemo" component={ThreeDemo} durationInFrames={120} fps={30} width={1920} height={1080} />
      <Composition id="PathDemo" component={PathDemo} durationInFrames={120} fps={30} width={1920} height={1080} />
      <Composition id="Showcase" component={Showcase} durationInFrames={SHOWCASE_DURATION} fps={30} width={1920} height={1080} defaultProps={{ labels: SHOWCASE_ZH, lang: "zh" as const }} />
      <Composition id="ShowcaseEn" component={Showcase} durationInFrames={SHOWCASE_DURATION} fps={30} width={1920} height={1080} defaultProps={{ labels: SHOWCASE_EN, lang: "en" as const }} />
      <Composition id="CanvasDemo" component={CanvasDemo} durationInFrames={120} fps={30} width={1920} height={1080} />
      <Composition id="SunnyBars" component={SunnyBars} durationInFrames={SUNNY_BARS_DURATION} fps={30} width={1920} height={1080} />
      <Composition id="Intro" component={Intro} durationInFrames={INTRO_DURATION} fps={30} width={1920} height={1080} defaultProps={{ lang: "zh" as const }} />
      <Composition id="IntroEn" component={Intro} durationInFrames={INTRO_DURATION} fps={30} width={1920} height={1080} defaultProps={{ lang: "en" as const }} />
    </>
  );
};
