import React from "react";
import { AbsoluteFill, Sequence, Series, interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { GsapDemo } from "./demos/GsapDemo";
import { D3Demo } from "./demos/D3Demo";
import { LottieDemo } from "./demos/LottieDemo";
import { ThreeDemo } from "./demos/ThreeDemo";
import { PathDemo } from "./demos/PathDemo";
import { CanvasDemo } from "./demos/CanvasDemo";

const FONT = '"Noto Sans CJK TC", system-ui, sans-serif';
const SEG = 105; // 每段 3.5 秒
export const SHOWCASE_OUTRO = 75;
export const SHOWCASE_DURATION = SEG * 6 + SHOWCASE_OUTRO;

const OUTRO_TEXT = {
  zh: { heading: "全部都是程式碼算出來的", site: "wellstsai.com" },
  en: { heading: "Every frame rendered from code", site: "wellstsai.com" },
};

// 收尾卡，跟片頭那支影片同一個暖色系，看起來像同一套
const Outro: React.FC<{ lang: "zh" | "en" }> = ({ lang }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const t = OUTRO_TEXT[lang];
  const enter = interpolate(frame, [0, 14], [0, 1], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });
  const exit = interpolate(frame, [SHOWCASE_OUTRO - 14, SHOWCASE_OUTRO], [1, 0], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });
  const pop = spring({ frame: frame - 8, fps, config: { damping: 12, mass: 0.6 } });

  return (
    <AbsoluteFill
      style={{
        background: "linear-gradient(150deg, #fffaf2 0%, #ffeedd 46%, #fef6c9 100%)",
        justifyContent: "center",
        alignItems: "center",
        fontFamily: FONT,
        opacity: enter * exit,
      }}
    >
      <div
        style={{
          fontSize: 76,
          fontWeight: 700,
          color: "#1f2937",
          opacity: pop,
          transform: `translateY(${interpolate(pop, [0, 1], [26, 0])}px)`,
        }}
      >
        {t.heading}
      </div>
      <div
        style={{
          marginTop: 34,
          fontSize: 36,
          letterSpacing: 3,
          color: "#f97316",
          fontWeight: 700,
          opacity: interpolate(frame, [24, 40], [0, 1], {
            extrapolateLeft: "clamp",
            extrapolateRight: "clamp",
          }),
        }}
      >
        {t.site}
      </div>
    </AbsoluteFill>
  );
};

export type ShowcaseProps = { labels: string[]; lang: "zh" | "en" };

// 角落的套件名稱，進場淡入、出場淡出
const Label: React.FC<{ text: string }> = ({ text }) => {
  const frame = useCurrentFrame();
  const opacity = interpolate(
    frame,
    [0, 12, SEG - 12, SEG],
    [0, 1, 1, 0],
    { extrapolateLeft: "clamp", extrapolateRight: "clamp" },
  );

  return (
    <AbsoluteFill style={{ justifyContent: "flex-end", padding: 64, opacity }}>
      <div
        style={{
          alignSelf: "flex-start",
          fontFamily: FONT,
          fontSize: 34,
          fontWeight: 700,
          color: "#e2e8f0",
          background: "rgba(2, 6, 23, 0.72)",
          border: "1px solid rgba(255,255,255,0.12)",
          borderRadius: 999,
          padding: "14px 30px",
        }}
      >
        {text}
      </div>
    </AbsoluteFill>
  );
};

const EN_MONTHS = ["Mar", "Apr", "May", "Jun", "Jul", "Aug"];

export const Showcase: React.FC<ShowcaseProps> = ({ labels, lang }) => {
  const en = lang === "en";
  const scenes = [
    <GsapDemo title={en ? "GSAP timeline" : undefined} />,
    <D3Demo months={en ? EN_MONTHS : undefined} />,
    <LottieDemo caption={en ? "Lottie playing" : undefined} />,
    <ThreeDemo />,
    <PathDemo />,
    <CanvasDemo />,
  ];

  return (
    <AbsoluteFill style={{ background: "#0b1220" }}>
      <Sequence durationInFrames={SEG * 6} layout="none">
      <Series>
        {scenes.map((scene, i) => (
          <Series.Sequence key={i} durationInFrames={SEG}>
            {scene}
            <Label text={labels[i]} />
          </Series.Sequence>
        ))}
      </Series>
      </Sequence>
      <Sequence from={SEG * 6} durationInFrames={SHOWCASE_OUTRO} layout="none">
        <Outro lang={lang} />
      </Sequence>
    </AbsoluteFill>
  );
};
