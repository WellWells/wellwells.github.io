import React from "react";
import {
  AbsoluteFill,
  Html5Audio,
  Sequence,
  Series,
  interpolate,
  random,
  spring,
  staticFile,
  useCurrentFrame,
  useVideoConfig,
} from "remotion";
import { Freeze } from "remotion";
import { ding, mouseClick, pageTurn, whip, whoosh } from "@remotion/sfx";
import { SunnyBars, SUNNY_BARS_DURATION } from "./demos/SunnyBars";

const FONT = '"Noto Sans CJK TC", "Noto Sans TC", system-ui, sans-serif';
const MONO = '"Noto Sans Mono CJK TC", ui-monospace, monospace';

const INK = "#1f2937";
const INK_SOFT = "#5b6472";
const INK_FAINT = "#9aa3b0";
const PAPER = "#fffdf8";
const TERM_BG = "#2a2422";

// 每一段換一個顏色，整支影片才不會從頭到尾一種調
const ACCENTS = ["#f97316", "#e11d48", "#f59e0b", "#10b981", "#0284c7", "#7c3aed", "#db2777"];

export const TITLE_LEN = 110;
export const OUTRO_LEN = 165;

// 每段 = 動畫跑完的幀數 + 靜止 60~84 幀（2~2.8 秒）+ 18 幀淡出
//        1    2    3    4    5    6    7
// 跑完  94  210  150  122  174  106   84
export const SCENE_LEN = [172, 312, 240, 224, 264, 208, 162];
export const BODY_LEN = SCENE_LEN.reduce((a, b) => a + b, 0);
export const INTRO_DURATION = TITLE_LEN + BODY_LEN + OUTRO_LEN;

const SCENE_START = SCENE_LEN.reduce<number[]>((acc, len, i) => {
  acc.push(i === 0 ? 0 : acc[i - 1] + SCENE_LEN[i - 1]);
  return acc;
}, []);

const FADE_IN = 14;
const FADE_OUT = 18;

export type IntroProps = { lang: "zh" | "en" };

/* ---------- 文案 ---------- */

const T = {
  zh: {
    title: "用程式碼做影片動畫",
    subtitle: "Remotion 從零開始，讓 AI 幫你改",
    steps: [
      { title: "畫面是寫出來的", caption: "版面用 React 元件描述，動畫是幀數的函式" },
      { title: "開好資料夾就開工", caption: "打開終端機、確認 Node、跑安裝精靈，一氣呵成" },
      { title: "打開 Studio", caption: "它是開發伺服器：存檔就重新編譯，預覽即時更新" },
      { title: "改資料，畫面跟著變", caption: "改陣列裡的字、多加一筆，時間軸自己重算" },
      { title: "讓 AI 幫你改", caption: "一句話丟給代理，它寫檔案，Studio 直接跑出來" },
      { title: "這時候才產生影片檔", caption: "無頭瀏覽器逐幀截圖，交給 ffmpeg 編碼成檔案" },
      { title: "接到剪輯軟體", caption: "透明版本疊在螢幕錄影上，進場點對齊旁白" },
    ],
    folder: "remotion-lab",
    termIcon: "終端機",
    termTitle: "終端機",
    s1: { code: ["const x = interpolate(", "  frame, [0, 30], [-80, 0]", ");"], comment: "// 第幾幀，就該在哪裡", frameLabel: "幀" },
    s2: { wizard: ["? Choose a template › Blank", "? TypeScript › Yes", "? Tailwind › No"], done: "專案建好了" },
    s3: { ready: "Server ready — http://localhost:3000", browser: "localhost:3000", comps: "Compositions", timeline: "時間軸", save: "存檔", refresh: "重新編譯，預覽更新" },
    s4: { before: "風格要一致", after: "顏色要統一", added: "多一張卡", cards: ["不要過度動畫", "不要圖文不符"], note: "存檔" },
    s5: {
      done: "12 個技能裝好了",
      prompt: "五根彩色長條從底部彈起來",
      writing: "寫入 src/demos/SunnyBars.tsx",
      result: "Studio 的預覽",
      tools: ["Claude Code", "Codex CLI", "Antigravity"],
    },
    s6: { pipeline: ["Root.tsx", "無頭瀏覽器逐幀截圖", "ffmpeg 編碼"], out: "video.mp4", alpha: "透明背景版本也是同一份程式碼" },
    s7: { tracks: ["螢幕錄影", "Remotion 動畫", "旁白"] },
    outro: { heading: "三行指令就跑得起來", site: "wellstsai.com" },
  },
  en: {
    title: "Animate video with code",
    subtitle: "Remotion from scratch, edited by an AI agent",
    steps: [
      { title: "The frame is written", caption: "The layout is a React component, the motion a function of the frame" },
      { title: "A folder, then straight to work", caption: "Open a terminal, check Node, run the wizard, all in one go" },
      { title: "Open the Studio", caption: "It's a dev server: save the file, it recompiles, the preview updates" },
      { title: "Edit data, the video follows", caption: "Change a string, add a row, and the timeline recalculates" },
      { title: "Let an AI edit it", caption: "One sentence to the agent, it writes the file, the Studio plays it" },
      { title: "Now the file gets made", caption: "A headless browser shoots every frame, ffmpeg encodes them" },
      { title: "Into an editor", caption: "Drop the transparent file over a screen recording, synced to narration" },
    ],
    folder: "remotion-lab",
    termIcon: "Terminal",
    termTitle: "Terminal",
    s1: { code: ["const x = interpolate(", "  frame, [0, 30], [-80, 0]", ");"], comment: "// which frame, which position", frameLabel: "frame" },
    s2: { wizard: ["? Choose a template › Blank", "? TypeScript › Yes", "? Tailwind › No"], done: "Project created" },
    s3: { ready: "Server ready — http://localhost:3000", browser: "localhost:3000", comps: "Compositions", timeline: "Timeline", save: "save", refresh: "recompiled, preview updated" },
    s4: { before: "Hold one style", after: "Keep colours tight", added: "One more card", cards: ["Don't over-animate", "Keep text and visuals in sync"], note: "save" },
    s5: {
      done: "12 skills installed",
      prompt: "five colourful bars springing up from the bottom",
      writing: "writing src/demos/SunnyBars.tsx",
      result: "the Studio preview",
      tools: ["Claude Code", "Codex CLI", "Antigravity"],
    },
    s6: { pipeline: ["Root.tsx", "headless browser, frame by frame", "ffmpeg encodes"], out: "video.mp4", alpha: "the transparent version is the same code" },
    s7: { tracks: ["Screen recording", "Remotion animation", "Narration"] },
    outro: { heading: "Three commands and it runs", site: "wellstsai.com" },
  },
};

type Strings = (typeof T)["zh"];

/* ---------- 小工具 ---------- */

const clampFade = { extrapolateLeft: "clamp", extrapolateRight: "clamp" } as const;

const Typed: React.FC<{ text: string; start: number; speed?: number; color?: string }> = ({
  text,
  start,
  speed = 1.8,
  color = "#f4efe9",
}) => {
  const frame = useCurrentFrame();
  const n = Math.max(0, Math.min(text.length, Math.floor((frame - start) * speed)));
  const done = n >= text.length;
  return (
    <div style={{ color, whiteSpace: "pre", minHeight: 48 }}>
      {frame < start ? " " : text.slice(0, n)}
      {frame >= start && !done ? "▌" : ""}
    </div>
  );
};

const FadeLine: React.FC<{ children: React.ReactNode; at: number; color?: string }> = ({
  children,
  at,
  color = "#c9c0b6",
}) => {
  const frame = useCurrentFrame();
  return (
    <div
      style={{
        color,
        whiteSpace: "pre",
        minHeight: 48,
        opacity: interpolate(frame, [at, at + 10], [0, 1], clampFade),
      }}
    >
      {children}
    </div>
  );
};

const Term: React.FC<{
  children: React.ReactNode;
  fontSize?: number;
  label?: string;
  style?: React.CSSProperties;
}> = ({ children, fontSize = 29, label, style }) => (
  <div
    style={{
      background: TERM_BG,
      borderRadius: 20,
      overflow: "hidden",
      boxShadow: "0 18px 44px rgba(120, 72, 30, 0.22)",
      ...style,
    }}
  >
    <div
      style={{
        display: "flex",
        alignItems: "center",
        gap: 10,
        padding: "16px 22px",
        background: "rgba(255,255,255,0.06)",
      }}
    >
      {["#ff5f57", "#febc2e", "#28c840"].map((c) => (
        <div key={c} style={{ width: 14, height: 14, borderRadius: 7, background: c }} />
      ))}
      {label ? <div style={{ marginLeft: 16, fontSize: 22, color: "#a99f95" }}>{label}</div> : null}
    </div>
    <div style={{ padding: "24px 30px", fontFamily: MONO, fontSize, lineHeight: 1.65 }}>
      {children}
    </div>
  </div>
);

const Card: React.FC<{ children: React.ReactNode; style?: React.CSSProperties }> = ({
  children,
  style,
}) => (
  <div
    style={{
      background: PAPER,
      borderRadius: 20,
      border: "2px solid rgba(176, 132, 74, 0.18)",
      boxShadow: "0 16px 40px rgba(146, 96, 40, 0.16)",
      ...style,
    }}
  >
    {children}
  </div>
);

const Pill: React.FC<{ text: string; at: number; accent: string }> = ({ text, at, accent }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const s = spring({ frame: frame - at, fps, config: { damping: 11, mass: 0.5 } });
  return (
    <div
      style={{
        fontSize: 30,
        fontWeight: 600,
        color: accent,
        background: PAPER,
        border: `2px solid ${accent}44`,
        borderRadius: 999,
        padding: "14px 32px",
        boxShadow: "0 10px 24px rgba(146, 96, 40, 0.14)",
        opacity: s,
        transform: `scale(${interpolate(s, [0, 1], [0.7, 1])})`,
      }}
    >
      {text}
    </div>
  );
};

const Cursor: React.FC<{ x: number; y: number; opacity?: number }> = ({ x, y, opacity = 1 }) => (
  <svg
    width={36}
    height={48}
    viewBox="0 0 24 32"
    style={{ position: "absolute", left: x, top: y, opacity, filter: "drop-shadow(0 3px 6px rgba(80,50,20,0.45))" }}
  >
    <path
      d="M2 2 L2 25 L8.5 18.5 L12.5 29 L16.5 27 L12.5 17 L21 17 Z"
      fill="#ffffff"
      stroke={INK}
      strokeWidth={1.8}
      strokeLinejoin="round"
    />
  </svg>
);

const MiniCard: React.FC<{ no: string; text: string; at: number; accent: string; highlight?: boolean }> = ({
  no,
  text,
  at,
  accent,
  highlight,
}) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const s = spring({ frame: frame - at, fps, config: { damping: 11, mass: 0.6 } });
  return (
    <div
      style={{
        display: "flex",
        alignItems: "center",
        gap: 18,
        padding: "16px 26px",
        borderRadius: 16,
        background: highlight ? `${accent}22` : PAPER,
        boxShadow: "0 10px 26px rgba(146, 96, 40, 0.14)",
        opacity: s,
        transform: `translateX(${interpolate(s, [0, 1], [-70, 0])}px)`,
      }}
    >
      <div
        style={{
          width: 46,
          height: 46,
          flexShrink: 0,
          borderRadius: 23,
          background: accent,
          color: "#fff",
          fontSize: 25,
          fontWeight: 700,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        {no}
      </div>
      <div style={{ fontSize: 28, fontWeight: 600, color: INK, whiteSpace: "nowrap" }}>{text}</div>
    </div>
  );
};

/* ---------- 每一段共用的外框 ---------- */

const Chrome: React.FC<{ t: Strings; step: number; children: React.ReactNode }> = ({
  t,
  step,
  children,
}) => {
  const frame = useCurrentFrame();
  const dur = SCENE_LEN[step];
  const info = t.steps[step];
  const accent = ACCENTS[step];

  const enter = interpolate(frame, [0, FADE_IN], [0, 1], clampFade);
  const exit = interpolate(frame, [dur - FADE_OUT, dur], [1, 0], clampFade);
  const capOpacity = interpolate(frame, [22, 34], [0, 1], clampFade);
  const progress = ((SCENE_START[step] + frame) / BODY_LEN) * 100;

  return (
    <AbsoluteFill
      style={{
        opacity: enter * exit,
        transform: `translateY(${interpolate(enter, [0, 1], [16, 0])}px)`,
        padding: "70px 80px 56px",
        display: "flex",
        flexDirection: "column",
      }}
    >
      <div style={{ display: "flex", alignItems: "center", gap: 22 }}>
        <div
          style={{
            width: 54,
            height: 54,
            borderRadius: 27,
            background: accent,
            color: "#fff",
            fontSize: 29,
            fontWeight: 700,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            boxShadow: `0 8px 20px ${accent}55`,
          }}
        >
          {step + 1}
        </div>
        <div style={{ fontSize: 45, fontWeight: 700, color: INK }}>{info.title}</div>
        <div style={{ marginLeft: "auto", fontSize: 26, color: INK_FAINT, fontFamily: MONO }}>
          {step + 1} / {SCENE_LEN.length}
        </div>
      </div>

      <div style={{ flex: 1, display: "flex", flexDirection: "column", justifyContent: "center", position: "relative" }}>
        {children}
      </div>

      <div style={{ fontSize: 32, color: INK_SOFT, opacity: capOpacity }}>{info.caption}</div>
      <div style={{ marginTop: 22, height: 6, borderRadius: 3, background: "rgba(160,120,70,0.16)" }}>
        <div style={{ width: `${progress}%`, height: 6, borderRadius: 3, background: accent }} />
      </div>
    </AbsoluteFill>
  );
};

/* ---------- 1：畫面是寫出來的 ---------- */

const Scene1: React.FC<{ t: Strings }> = ({ t }) => {
  const frame = useCurrentFrame();
  const accent = ACCENTS[0];
  const playhead = interpolate(frame, [34, 94], [0, 40], clampFade);
  const x = interpolate(playhead, [0, 30], [-80, 0], clampFade);

  return (
    <Chrome t={t} step={0}>
      <div style={{ display: "flex", alignItems: "center", gap: 48 }}>
        <Term fontSize={27} style={{ flex: 1 }}>
          <FadeLine at={6} color="#9c9086">
            {t.s1.comment}
          </FadeLine>
          {t.s1.code.map((line, i) => (
            <FadeLine key={line} at={14 + i * 8} color="#f4efe9">
              {line}
            </FadeLine>
          ))}
        </Term>

        <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 14 }}>
          {[0, 1, 2].map((i) => (
            <div
              key={i}
              style={{
                width: 16,
                height: 16,
                borderRadius: 8,
                background: accent,
                opacity: interpolate((frame - 30 - i * 6) % 30, [0, 8, 16, 30], [0.18, 1, 0.18, 0.18], clampFade),
              }}
            />
          ))}
        </div>

        <Card style={{ flex: 1, aspectRatio: "16 / 9", position: "relative", display: "flex", alignItems: "center", paddingLeft: 110, overflow: "hidden" }}>
          <div style={{ transform: `translateX(${x}px)`, opacity: interpolate(playhead, [0, 12], [0, 1], clampFade) }}>
            <MiniCard no="1" text={t.steps[0].title} at={-999} accent={accent} />
          </div>
          <div style={{ position: "absolute", right: 26, bottom: 22, fontFamily: MONO, fontSize: 25, fontWeight: 700, color: accent }}>
            {t.s1.frameLabel} {Math.round(playhead)}
          </div>
        </Card>
      </div>
    </Chrome>
  );
};

/* ---------- 2：開好資料夾就開工 ---------- */

const ICON = { x: 56, folderY: 48, termY: 250, w: 170, iconW: 112, iconH: 90 };
const TERM_ORIGIN = { x: ICON.x + ICON.w / 2, y: ICON.termY + ICON.iconH / 2 };
const WIN = { left: 300, top: 48, width: 1400, height: 566 };

const DesktopIcon: React.FC<{ top: number; label: string; progress: number; children: React.ReactNode }> = ({
  top,
  label,
  progress,
  children,
}) => (
  <div
    style={{
      position: "absolute",
      left: ICON.x,
      top,
      width: ICON.w,
      textAlign: "center",
      opacity: progress,
      transform: `scale(${interpolate(progress, [0, 1], [0.6, 1])})`,
    }}
  >
    {children}
    <div style={{ marginTop: 14, fontSize: 23, fontWeight: 600, color: INK, whiteSpace: "nowrap" }}>{label}</div>
  </div>
);

const Scene2: React.FC<{ t: Strings }> = ({ t }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const accent = ACCENTS[1];

  const folderIn = spring({ frame: frame - 8, fps, config: { damping: 11, mass: 0.6 } });
  const termIn = spring({ frame: frame - 24, fps, config: { damping: 11, mass: 0.6 } });

  const move = interpolate(frame, [38, 62], [0, 1], clampFade);
  const eased = move * move * (3 - 2 * move);
  const cx = interpolate(eased, [0, 1], [1480, TERM_ORIGIN.x - 6]);
  const cy = interpolate(eased, [0, 1], [700, TERM_ORIGIN.y - 4]);
  const cursorOpacity = interpolate(frame, [32, 42, 104, 116], [0, 1, 1, 0], clampFade);

  const open = spring({ frame: frame - 74, fps, durationInFrames: 22, config: { damping: 200 } });

  return (
    <Chrome t={t} step={1}>
      <div style={{ position: "relative", height: 720 }}>
        <div
          style={{
            position: "absolute",
            inset: 0,
            borderRadius: 24,
            background: "linear-gradient(150deg, rgba(255,255,255,0.75), rgba(255,255,255,0.35))",
            boxShadow: "inset 0 0 0 2px rgba(180,140,90,0.14)",
          }}
        />

        <DesktopIcon top={ICON.folderY} label={t.folder} progress={folderIn}>
          <div style={{ width: ICON.iconW, height: ICON.iconH, position: "relative", margin: "0 auto" }}>
            <div style={{ position: "absolute", top: 0, left: 0, width: 50, height: 15, borderRadius: "6px 6px 0 0", background: "#f59e0b" }} />
            <div style={{ position: "absolute", top: 12, left: 0, right: 0, bottom: 0, borderRadius: 12, background: "linear-gradient(160deg, #fbbf24, #f59e0b)", boxShadow: "0 10px 22px rgba(245,158,11,0.4)" }} />
          </div>
        </DesktopIcon>

        <DesktopIcon top={ICON.termY} label={t.termIcon} progress={termIn}>
          <div
            style={{
              width: ICON.iconW,
              height: ICON.iconH,
              margin: "0 auto",
              borderRadius: 16,
              background: TERM_BG,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              fontFamily: MONO,
              fontSize: 38,
              color: "#fcd34d",
              boxShadow: "0 10px 22px rgba(80,50,20,0.3)",
            }}
          >
            {">_"}
          </div>
        </DesktopIcon>

        {[62, 70].map((at) => {
          const p = interpolate(frame, [at, at + 14], [0, 1], clampFade);
          return (
            <div
              key={at}
              style={{
                position: "absolute",
                left: TERM_ORIGIN.x - 60,
                top: TERM_ORIGIN.y - 60,
                width: 120,
                height: 120,
                borderRadius: 60,
                border: `4px solid ${accent}`,
                opacity: (1 - p) * 0.6,
                transform: `scale(${0.4 + p * 1.5})`,
              }}
            />
          );
        })}

        <div
          style={{
            position: "absolute",
            left: WIN.left,
            top: WIN.top,
            width: WIN.width,
            opacity: open,
            transformOrigin: "0 0",
            transform: `translate(${(TERM_ORIGIN.x - WIN.left) * (1 - open)}px, ${(TERM_ORIGIN.y - WIN.top) * (1 - open)}px) scale(${0.1 + open * 0.9})`,
          }}
        >
          <Term fontSize={28} label={`${t.termTitle} — ${t.folder}`} style={{ height: WIN.height }}>
            <Typed text="$ cd remotion-lab" start={102} />
            <Typed text="$ node --version" start={118} />
            <FadeLine at={132} color="#86efac">
              v24.11.1
            </FadeLine>
            <Typed text="$ npx create-video@latest" start={148} />
            {t.s2.wizard.map((line, i) => (
              <FadeLine key={line} at={168 + i * 8} color="#e7dfd6">
                {line}
              </FadeLine>
            ))}
            <FadeLine at={200} color="#86efac">
              {`✔ ${t.s2.done}`}
            </FadeLine>
          </Term>
        </div>

        <Cursor x={cx} y={cy} opacity={cursorOpacity} />
      </div>
    </Chrome>
  );
};

/* ---------- 3：打開 Studio ---------- */

const Scene3: React.FC<{ t: Strings }> = ({ t }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const accent = ACCENTS[2];
  const open = spring({ frame: frame - 42, fps, durationInFrames: 20, config: { damping: 200 } });
  const playhead = interpolate(frame, [68, 114], [0, 100], clampFade);
  const cardX = interpolate(playhead, [0, 40], [-60, 0], clampFade);
  const termDim = interpolate(frame, [42, 60], [1, 0.66], clampFade);
  // 存檔 → 重新編譯 → 預覽更新，這一段就是 tsx 怎麼變成畫面
  const saveIn = spring({ frame: frame - 120, fps, config: { damping: 12, mass: 0.5 } });
  const refreshIn = interpolate(frame, [136, 150], [0, 1], clampFade);

  return (
    <Chrome t={t} step={2}>
      <div style={{ position: "relative", height: 692 }}>
        <div style={{ position: "absolute", left: 0, top: 0, width: 960, opacity: termDim }}>
          <Term fontSize={27} label={t.termTitle}>
            <Typed text="$ npx remotion studio" start={6} />
            <FadeLine at={24} color="#86efac">
              {t.s3.ready}
            </FadeLine>
          </Term>
        </div>

        {/* 存檔的提示，貼在終端機右邊 */}
        <div
          style={{
            position: "absolute",
            left: 1010,
            top: 40,
            display: "flex",
            alignItems: "center",
            gap: 18,
            opacity: saveIn,
            transform: `scale(${interpolate(saveIn, [0, 1], [0.8, 1])})`,
          }}
        >
          <div style={{ fontFamily: MONO, fontSize: 26, fontWeight: 700, color: accent, background: PAPER, borderRadius: 14, padding: "14px 24px", boxShadow: "0 10px 24px rgba(146,96,40,0.16)" }}>
            {`⌘S  Root.tsx  ${t.s3.save}`}
          </div>
          <div style={{ fontSize: 30, color: accent, opacity: refreshIn }}>→</div>
          <div style={{ fontSize: 26, fontWeight: 600, color: INK, opacity: refreshIn }}>{t.s3.refresh}</div>
        </div>

        <div
          style={{
            position: "absolute",
            left: 0,
            top: 230,
            width: 1760,
            opacity: open,
            transform: `translateY(${interpolate(open, [0, 1], [46, 0])}px) scale(${interpolate(open, [0, 1], [0.95, 1])})`,
            transformOrigin: "50% 0",
          }}
        >
          <Card style={{ overflow: "hidden", padding: 0 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "16px 22px", background: "rgba(176,132,74,0.16)", borderBottom: "2px solid rgba(176,132,74,0.18)" }}>
              {["#ff5f57", "#febc2e", "#28c840"].map((c) => (
                <div key={c} style={{ width: 14, height: 14, borderRadius: 7, background: c }} />
              ))}
              <div style={{ marginLeft: 18, width: 460, background: "#fff", border: "1px solid rgba(176,132,74,0.24)", borderRadius: 999, padding: "9px 22px", fontFamily: MONO, fontSize: 21, color: INK_SOFT }}>
                {t.s3.browser}
              </div>
            </div>

            <div style={{ display: "flex", height: 400 }}>
              <div style={{ width: 320, borderRight: "2px solid rgba(176,132,74,0.22)", padding: "24px 22px" }}>
                <div style={{ fontSize: 19, letterSpacing: 2, color: INK_FAINT, marginBottom: 18 }}>
                  {t.s3.comps.toUpperCase()}
                </div>
                {["TitleCards", "TitleCardsAlpha", "Cover"].map((c, i) => (
                  <div
                    key={c}
                    style={{
                      fontFamily: MONO,
                      fontSize: 22,
                      padding: "11px 14px",
                      borderRadius: 10,
                      marginBottom: 6,
                      fontWeight: i === 0 ? 700 : 400,
                      color: i === 0 ? accent : INK_SOFT,
                      background: i === 0 ? `${accent}1e` : "transparent",
                    }}
                  >
                    {c}
                  </div>
                ))}
              </div>

              <div style={{ flex: 1, padding: 26, display: "flex", flexDirection: "column" }}>
                <div style={{ flex: 1, background: "#f3e7d5", borderRadius: 12, display: "flex", alignItems: "center", paddingLeft: 60, overflow: "hidden" }}>
                  <div style={{ transform: `translateX(${cardX}px)`, opacity: interpolate(playhead, [0, 26], [0, 1], clampFade) }}>
                    <MiniCard no="1" text={t.s4.cards[0]} at={-999} accent={accent} />
                  </div>
                </div>
                <div style={{ marginTop: 20 }}>
                  <div style={{ fontSize: 18, color: INK_FAINT, marginBottom: 9 }}>{t.s3.timeline}</div>
                  <div style={{ position: "relative", height: 30, background: "rgba(176,132,74,0.20)", borderRadius: 8 }}>
                    <div style={{ position: "absolute", inset: 0, width: `${playhead}%`, background: `${accent}44`, borderRadius: 8 }} />
                    <div style={{ position: "absolute", top: -6, bottom: -6, left: `${playhead}%`, width: 4, background: accent, borderRadius: 2 }} />
                  </div>
                </div>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </Chrome>
  );
};

/* ---------- 4：改資料，畫面跟著變 ---------- */

const retype = (frame: number, start: number, before: string, after: string, speed = 0.9) => {
  const p = (frame - start) * speed;
  if (p <= 0) return before;
  if (p < before.length) return before.slice(0, before.length - Math.floor(p));
  return after.slice(0, Math.min(after.length, Math.floor(p - before.length)));
};

const EDIT_AT = 52;
const ADD_AT = 104;

const Scene4: React.FC<{ t: Strings }> = ({ t }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const accent = ACCENTS[3];

  const third = retype(frame, EDIT_AT, t.s4.before, t.s4.after);
  const editing = frame > EDIT_AT && frame < EDIT_AT + 40;
  const addIn = spring({ frame: frame - ADD_AT, fps, durationInFrames: 18, config: { damping: 200 } });
  const saveFlash = interpolate(frame, [92, 100, 112], [0, 1, 0], clampFade);

  return (
    <Chrome t={t} step={3}>
      <div style={{ display: "flex", gap: 44, alignItems: "flex-start" }}>
        <div style={{ flex: 1.1 }}>
          <Term fontSize={25} label="Root.tsx">
            <FadeLine at={4} color="#f4efe9">
              {"cards: ["}
            </FadeLine>
            <FadeLine at={10} color="#f4efe9">
              {`  { no: "1", title: "${t.s4.cards[0]}" },`}
            </FadeLine>
            <FadeLine at={16} color="#f4efe9">
              {`  { no: "2", title: "${t.s4.cards[1]}" },`}
            </FadeLine>
            <div
              style={{
                whiteSpace: "pre",
                color: "#f4efe9",
                minHeight: 48,
                opacity: interpolate(frame, [22, 32], [0, 1], clampFade),
                background: editing ? "rgba(16,185,129,0.24)" : "transparent",
                borderRadius: 6,
              }}
            >
              {`  { no: "3", title: "${third}" },`}
              {editing ? "▌" : ""}
            </div>
            <div style={{ whiteSpace: "pre", color: "#86efac", height: addIn * 48, overflow: "hidden", opacity: addIn }}>
              {`  { no: "4", title: "${t.s4.added}" },`}
            </div>
            <div style={{ color: "#f4efe9", whiteSpace: "pre" }}>]</div>
          </Term>

          <div style={{ marginTop: 20, fontSize: 26, fontFamily: MONO, fontWeight: 700, color: accent, opacity: saveFlash }}>
            {`⌘S  ${t.s4.note}`}
          </div>
        </div>

        <Card style={{ flex: 1, padding: "40px 38px", display: "flex", flexDirection: "column", gap: 18, background: "#fdf6ec" }}>
          <MiniCard no="1" text={t.s4.cards[0]} at={8} accent={accent} />
          <MiniCard no="2" text={t.s4.cards[1]} at={18} accent={accent} />
          <MiniCard no="3" text={third} at={28} accent={accent} highlight={editing} />
          <div style={{ opacity: addIn, transform: `translateY(${interpolate(addIn, [0, 1], [20, 0])}px)` }}>
            <MiniCard no="4" text={t.s4.added} at={-999} accent={accent} />
          </div>
        </Card>
      </div>
    </Chrome>
  );
};

/* ---------- 5：讓 AI 幫你改（真的跑過一次） ---------- */

const SUNNY_AT = 84;

const Scene5: React.FC<{ t: Strings }> = ({ t }) => {
  const frame = useCurrentFrame();
  const accent = ACCENTS[4];
  const previewIn = interpolate(frame, [SUNNY_AT - 8, SUNNY_AT + 6], [0, 1], clampFade);

  return (
    <Chrome t={t} step={4}>
      <div style={{ display: "flex", gap: 40, alignItems: "flex-start" }}>
        <div style={{ flex: 1 }}>
          <Term fontSize={25} label={t.termTitle}>
            <Typed text="$ npx remotion skills add" start={6} />
            <FadeLine at={26} color="#86efac">
              {`✔ ${t.s5.done}`}
            </FadeLine>
            <Typed text={`> ${t.s5.prompt}`} start={44} speed={1.5} color="#fcd34d" />
            <FadeLine at={66} color="#c9c0b6">
              {`● ${t.s5.writing}`}
            </FadeLine>
          </Term>

          <div style={{ display: "flex", gap: 16, marginTop: 30, flexWrap: "wrap" }}>
            {t.s5.tools.map((tool, i) => (
              <Pill key={tool} text={tool} at={100 + i * 7} accent={accent} />
            ))}
          </div>
        </div>

        <div style={{ width: 860, flexShrink: 0, opacity: previewIn }}>
          <div style={{ fontSize: 24, color: INK_FAINT, marginBottom: 12 }}>{t.s5.result}</div>
          <Card style={{ width: 860, height: 484, overflow: "hidden", padding: 0 }}>
            {/* 這一段就是上面那句 prompt 產生出來的元件，原封不動跑在這裡 */}
            <Sequence from={SUNNY_AT} layout="none">
              {/* 跑滿 90 幀之後凍在最後一幀，不然這一格會空掉 */}
              <Freeze frame={SUNNY_BARS_DURATION - 1} active={(f) => f >= SUNNY_BARS_DURATION}>
                <div style={{ width: 1920, height: 1080, transform: "scale(0.4479)", transformOrigin: "0 0" }}>
                  <SunnyBars />
                </div>
              </Freeze>
            </Sequence>
          </Card>
        </div>
      </div>
    </Chrome>
  );
};

/* ---------- 6：這時候才產生影片檔 ---------- */

const Scene6: React.FC<{ t: Strings }> = ({ t }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const accent = ACCENTS[5];

  return (
    <Chrome t={t} step={5}>
      {/* tsx 到檔案的整條路徑 */}
      <div style={{ display: "flex", alignItems: "center", gap: 18, marginBottom: 40 }}>
        {t.s6.pipeline.map((label, i) => {
          const s = spring({ frame: frame - (6 + i * 12), fps, config: { damping: 12, mass: 0.5 } });
          return (
            <React.Fragment key={label}>
              {i > 0 ? (
                <div style={{ fontSize: 40, color: accent, opacity: interpolate(frame, [i * 12, 8 + i * 12], [0, 1], clampFade) }}>→</div>
              ) : null}
              <Card
                style={{
                  flex: 1,
                  padding: "26px 22px",
                  textAlign: "center",
                  fontSize: 28,
                  fontWeight: 600,
                  color: INK,
                  opacity: s,
                  transform: `translateY(${interpolate(s, [0, 1], [22, 0])}px)`,
                }}
              >
                {label}
              </Card>
            </React.Fragment>
          );
        })}
        <div style={{ fontSize: 40, color: accent, opacity: interpolate(frame, [36, 44], [0, 1], clampFade) }}>→</div>
        <div
          style={{
            padding: "26px 30px",
            borderRadius: 20,
            background: accent,
            color: "#fff",
            fontFamily: MONO,
            fontSize: 28,
            fontWeight: 700,
            boxShadow: `0 14px 30px ${accent}55`,
            opacity: interpolate(frame, [42, 54], [0, 1], clampFade),
          }}
        >
          {t.s6.out}
        </div>
      </div>

      <Term fontSize={26} label={t.termTitle}>
        <Typed text="$ npx remotion render TitleCards out/video.mp4" start={56} />
        <FadeLine at={84} color="#86efac">
          Rendered 180/180
        </FadeLine>
        <FadeLine at={96} color="#9c9086">
          {`# ${t.s6.alpha}`}
        </FadeLine>
      </Term>
    </Chrome>
  );
};

/* ---------- 7：接到剪輯軟體 ---------- */

const LANE_W = 1200;
const CLIP_LEFT = 420;
const NAR_BARS = 64;

const Scene7: React.FC<{ t: Strings }> = ({ t }) => {
  const frame = useCurrentFrame();
  const accent = ACCENTS[6];
  const slide = interpolate(frame, [30, 76], [220, 0], clampFade);
  const marker = interpolate(frame, [68, 84], [0, 1], clampFade);
  const hitBar = Math.round((CLIP_LEFT / LANE_W) * NAR_BARS);

  const row: React.CSSProperties = { display: "flex", alignItems: "center", gap: 24, marginBottom: 20 };
  const label: React.CSSProperties = { width: 300, flexShrink: 0, fontSize: 26, fontWeight: 600, color: INK_SOFT, textAlign: "right" };
  const lane: React.CSSProperties = {
    width: LANE_W,
    flexShrink: 0,
    height: 92,
    background: "rgba(160,120,70,0.12)",
    borderRadius: 12,
    position: "relative",
    overflow: "hidden",
  };

  return (
    <Chrome t={t} step={6}>
      <div style={{ position: "relative" }}>
        <div style={row}>
          <div style={label}>{t.s7.tracks[0]}</div>
          <div style={lane}>
            <div style={{ position: "absolute", inset: 8, borderRadius: 8, background: "rgba(120,90,60,0.22)" }} />
          </div>
        </div>

        <div style={row}>
          <div style={label}>{t.s7.tracks[1]}</div>
          <div style={lane}>
            <div
              style={{
                position: "absolute",
                top: 8,
                bottom: 8,
                left: CLIP_LEFT,
                width: 340,
                borderRadius: 8,
                background: accent,
                boxShadow: `0 8px 20px ${accent}55`,
                transform: `translateX(${slide}px)`,
              }}
            />
          </div>
        </div>

        <div style={row}>
          <div style={label}>{t.s7.tracks[2]}</div>
          <div style={{ ...lane, display: "flex", alignItems: "center", gap: 4, padding: "0 8px" }}>
            {new Array(NAR_BARS).fill(0).map((_, i) => {
              const hot = Math.abs(i - hitBar) < 2;
              return (
                <div
                  key={i}
                  style={{
                    flex: 1,
                    height: 12 + random(`nar-${i}`) * 58,
                    borderRadius: 3,
                    background: hot ? accent : "rgba(120,90,60,0.34)",
                    opacity: hot ? marker : 1,
                  }}
                />
              );
            })}
          </div>
        </div>

        <div style={{ position: "absolute", left: 324 + CLIP_LEFT, top: -14, bottom: -14, width: 4, borderRadius: 2, background: accent, opacity: marker }} />
      </div>
    </Chrome>
  );
};

/* ---------- 背景：暖色漸層加幾顆慢慢飄的色塊 ---------- */

const BLOBS = [
  { c: "#fdba74", size: 620, x: -140, y: -160, sx: 34, sy: 22, sp: 0.003 },
  { c: "#fca5a5", size: 520, x: 1500, y: -120, sx: -28, sy: 30, sp: 0.004 },
  { c: "#fde68a", size: 700, x: 1250, y: 640, sx: 26, sy: -24, sp: 0.0025 },
  { c: "#a7f3d0", size: 460, x: -100, y: 700, sx: 30, sy: 18, sp: 0.0035 },
  { c: "#bfdbfe", size: 400, x: 780, y: 880, sx: -22, sy: -28, sp: 0.0045 },
];

const Backdrop: React.FC = () => {
  // 完全靜止。背景一動，整個畫面每一幀都有殘差，位元率全花在看不見的地方；
  // 固定住之後同樣的檔案大小可以換到高很多的畫質。動感交給場景內容去做。
  return (
    <AbsoluteFill style={{ background: "linear-gradient(150deg, #fffaf2 0%, #ffeedd 46%, #fef6c9 100%)" }}>
      {BLOBS.map((b, i) => (
        <div
          key={i}
          style={{
            position: "absolute",
            left: b.x,
            top: b.y,
            width: b.size,
            height: b.size,
            borderRadius: "50%",
            background: b.c,
            opacity: 0.42,
            filter: "blur(90px)",
          }}
        />
      ))}
    </AbsoluteFill>
  );
};

/* ---------- 片頭與收尾 ---------- */

const TitleScene: React.FC<{ t: Strings }> = ({ t }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const s = spring({ frame, fps, config: { damping: 12, mass: 0.7 } });
  const out = interpolate(frame, [TITLE_LEN - 16, TITLE_LEN], [1, 0], clampFade);

  return (
    <AbsoluteFill style={{ justifyContent: "center", alignItems: "center", opacity: out }}>
      <div style={{ opacity: s, transform: `translateY(${interpolate(s, [0, 1], [40, 0])}px)`, textAlign: "center" }}>
        <div
          style={{
            display: "inline-block",
            fontSize: 26,
            fontWeight: 700,
            letterSpacing: 4,
            color: "#fff",
            background: ACCENTS[0],
            borderRadius: 999,
            padding: "12px 30px",
            marginBottom: 36,
            boxShadow: `0 12px 28px ${ACCENTS[0]}55`,
          }}
        >
          REMOTION
        </div>
        <div style={{ fontSize: 96, fontWeight: 700, color: INK, lineHeight: 1.25 }}>{t.title}</div>
        <div
          style={{
            fontSize: 38,
            color: INK_SOFT,
            marginTop: 28,
            opacity: interpolate(frame, [18, 34], [0, 1], clampFade),
          }}
        >
          {t.subtitle}
        </div>
      </div>
    </AbsoluteFill>
  );
};

const OUTRO_COMMANDS = ["npx create-video@latest", "npx remotion studio", "npx remotion render"];

const Outro: React.FC<{ t: Strings }> = ({ t }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  return (
    <AbsoluteFill style={{ justifyContent: "center", alignItems: "center", padding: 120 }}>
      <div style={{ fontSize: 58, fontWeight: 700, color: INK, marginBottom: 50, opacity: interpolate(frame, [0, 14], [0, 1], clampFade) }}>
        {t.outro.heading}
      </div>

      <div style={{ display: "flex", flexDirection: "column", gap: 20, width: 1080 }}>
        {OUTRO_COMMANDS.map((cmd, i) => {
          const s = spring({ frame: frame - (18 + i * 12), fps, config: { damping: 12, mass: 0.5 } });
          const accent = ACCENTS[i * 2];
          return (
            <div
              key={cmd}
              style={{
                display: "flex",
                alignItems: "center",
                gap: 20,
                padding: "24px 34px",
                borderRadius: 18,
                background: PAPER,
                borderLeft: `8px solid ${accent}`,
                boxShadow: "0 14px 32px rgba(146,96,40,0.16)",
                fontFamily: MONO,
                fontSize: 34,
                color: INK,
                opacity: s,
                transform: `translateX(${interpolate(s, [0, 1], [-40, 0])}px)`,
              }}
            >
              <span style={{ color: accent, fontWeight: 700 }}>$</span>
              {cmd}
            </div>
          );
        })}
      </div>

      <div style={{ marginTop: 56, fontSize: 32, letterSpacing: 2, color: INK_SOFT, opacity: interpolate(frame, [68, 82], [0, 1], clampFade) }}>
        {t.outro.site}
      </div>
    </AbsoluteFill>
  );
};

/* ---------- 聲音 ---------- */

const S = (i: number) => TITLE_LEN + SCENE_START[i];

const CUES: { at: number; src: string; volume: number }[] = [
  { at: 0, src: whoosh, volume: 0.18 },
  ...SCENE_LEN.map((_, i) => ({ at: S(i), src: whoosh, volume: 0.16 })),
  // 2：點兩下、視窗彈出來
  { at: S(1) + 60, src: mouseClick, volume: 0.34 },
  { at: S(1) + 68, src: mouseClick, volume: 0.34 },
  { at: S(1) + 72, src: pageTurn, volume: 0.24 },
  // 3：瀏覽器開起來
  { at: S(2) + 42, src: pageTurn, volume: 0.24 },
  // 4：三張卡加後來補的第四張
  { at: S(3) + 8, src: whip, volume: 0.26 },
  { at: S(3) + 18, src: whip, volume: 0.26 },
  { at: S(3) + 28, src: whip, volume: 0.26 },
  { at: S(3) + 104, src: whip, volume: 0.3 },
  // 5：AI 產出的五根長條依序彈起來
  ...[0, 6, 12, 18, 24].map((d) => ({ at: S(4) + SUNNY_AT + d, src: whip, volume: 0.2 })),
  { at: TITLE_LEN + BODY_LEN, src: ding, volume: 0.26 },
];

/* ---------- 組起來 ---------- */

const Body: React.FC<{ t: Strings }> = ({ t }) => {
  const scenes = [Scene1, Scene2, Scene3, Scene4, Scene5, Scene6, Scene7];
  return (
    <Series>
      {scenes.map((Scene, i) => (
        <Series.Sequence key={i} durationInFrames={SCENE_LEN[i]}>
          <Scene t={t} />
        </Series.Sequence>
      ))}
    </Series>
  );
};

export const Intro: React.FC<IntroProps> = ({ lang }) => {
  const t = T[lang];
  const frame = useCurrentFrame();

  const fade = interpolate(frame, [0, 20, INTRO_DURATION - 26, INTRO_DURATION], [0, 1, 1, 0], clampFade);

  return (
    <AbsoluteFill style={{ background: "#fffaf2", fontFamily: FONT }}>
      <AbsoluteFill style={{ opacity: fade }}>
        <Backdrop />
        <Sequence durationInFrames={TITLE_LEN} layout="none">
          <TitleScene t={t} />
        </Sequence>
        <Sequence from={TITLE_LEN} durationInFrames={BODY_LEN} layout="none">
          <Body t={t} />
        </Sequence>
        <Sequence from={TITLE_LEN + BODY_LEN} durationInFrames={OUTRO_LEN} layout="none">
          <Outro t={t} />
        </Sequence>
      </AbsoluteFill>

      <Html5Audio src={staticFile("ambient.wav")} volume={0.34} />
      {CUES.map((cue, i) => (
        <Sequence key={i} from={cue.at} layout="none">
          <Html5Audio src={cue.src} volume={cue.volume} />
        </Sequence>
      ))}
    </AbsoluteFill>
  );
};
