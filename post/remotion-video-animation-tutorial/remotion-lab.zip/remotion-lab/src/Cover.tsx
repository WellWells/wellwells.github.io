import React from "react";
import { AbsoluteFill } from "remotion";

const FONT = '"Noto Sans CJK TC", "Noto Sans TC", system-ui, sans-serif';
const MONO = '"Noto Sans Mono CJK TC", ui-monospace, monospace';

export type CoverProps = {
  title: string;
  subtitle: string;
  code: string[];
};

export const Cover: React.FC<CoverProps> = ({ title, subtitle, code }) => {
  return (
    <AbsoluteFill
      style={{
        background: "linear-gradient(135deg, #0b1220 0%, #111c33 100%)",
        fontFamily: FONT,
        padding: 90,
        justifyContent: "center",
      }}
    >
      <div style={{ display: "flex", gap: 64, alignItems: "center" }}>
        <div style={{ flex: 1 }}>
          <div
            style={{
              display: "inline-block",
              fontSize: 24,
              letterSpacing: 3,
              color: "#38bdf8",
              border: "1px solid rgba(56, 189, 248, 0.4)",
              borderRadius: 999,
              padding: "8px 22px",
              marginBottom: 30,
            }}
          >
            REMOTION
          </div>
          <div
            style={{
              fontSize: 72,
              fontWeight: 700,
              color: "#f8fafc",
              lineHeight: 1.25,
            }}
          >
            {title}
          </div>
          <div style={{ fontSize: 32, color: "#94a3b8", marginTop: 24 }}>
            {subtitle}
          </div>
        </div>

        <div
          style={{
            width: 620,
            flexShrink: 0,
            background: "rgba(2, 6, 23, 0.72)",
            border: "1px solid rgba(255,255,255,0.10)",
            borderRadius: 18,
            padding: 32,
            fontFamily: MONO,
            fontSize: 24,
            lineHeight: 1.7,
          }}
        >
          {code.map((line, i) => (
            <div
              key={i}
              style={{
                color: line.startsWith("//") ? "#64748b" : "#e2e8f0",
                whiteSpace: "pre",
              }}
            >
              {line === "" ? "\u00a0" : line}
            </div>
          ))}
        </div>
      </div>
    </AbsoluteFill>
  );
};
