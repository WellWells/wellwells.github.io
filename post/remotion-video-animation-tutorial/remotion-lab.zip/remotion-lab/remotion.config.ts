import { Config } from "@remotion/cli/config";
import { enableTailwind } from "@remotion/tailwind-v4";

Config.setRspack(true);
Config.setOverwriteOutput(true);
Config.overrideBundlerConfig(enableTailwind);

// 逐幀截圖用 PNG。JPEG 會先壓一次才進 h264，等於畫質被砍兩輪，
// 而且 JPEG 是全範圍 YUV，輸出會被標成 yuvj420p。
Config.setVideoImageFormat("png");

// 8-bit、限制範圍的 yuv420p，這是 iOS / Safari 唯一穩的組合。
Config.setPixelFormat("yuv420p");

// HD 該用 bt709。之前被標成 bt470bg + 全範圍，播放器會把亮度拉開，淺色畫面就過曝。
Config.setColorSpace("bt709");

// 壓得慢一點，同畫質可以省不少體積。
Config.setX264Preset("slow");
