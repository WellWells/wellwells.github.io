# Author: Wells @ wellstsai.com

import argparse
from faster_whisper import WhisperModel
from datetime import datetime, timedelta
import os

# config
# 預設值
DEFAULT_MODEL_SIZE = "large-v3"
DEFAULT_DEVICE = "cuda"
DEFAULT_TASK = "transcribe"
DEFAULT_COMPUTE_TYPE = "float16"

def format_time(seconds):
    minutes, seconds = divmod(seconds, 60)
    hours, minutes = divmod(minutes, 60)
    milliseconds = (seconds - int(seconds)) * 1000
    return f"{int(hours):02d}:{int(minutes):02d}:{int(seconds):02d},{int(milliseconds):03d}"

def transcribe_video(input_file, model_size, device, task, compute_type):
    # 計時開始
    start_time = datetime.now()
    print(f"轉寫開始時間：{start_time.strftime('%Y-%m-%d %H:%M:%S')}")

    model = WhisperModel(model_size, device=device, compute_type=compute_type)
    segments, info = model.transcribe(input_file, beam_size=5, task=task, vad_filter=True)

    print("Detected language '{}' with probability {:.2f}".format(
        info.language, info.language_probability))

    srt_filename = os.path.splitext(input_file)[0] + '.srt'
    with open(srt_filename, 'w', encoding='utf-8') as srt_file:
        for segment in segments:
            start = format_time(segment.start)
            end   = format_time(segment.end)
            text  = segment.text.lstrip()
            idx   = segment.id
            entry = f"{idx}\n{start} --> {end}\n{text}\n\n"
            print(entry)
            srt_file.write(entry)
            srt_file.flush()

    # 計時結束
    end_time = datetime.now()
    print(f"轉寫結束時間：{end_time.strftime('%Y-%m-%d %H:%M:%S')}")

    # 計算並輸出總時間（HH:MM:SS.ss）
    total_duration = end_time - start_time
    h, rem = divmod(total_duration.total_seconds(), 3600)
    m, s = divmod(rem, 60)
    print(f"總轉換時間：{int(h):02d}:{int(m):02d}:{s:05.2f}")

def main():
    parser = argparse.ArgumentParser(
        description="Transcribe audio from a video file and generate an SRT file.")
    parser.add_argument("input_file", help="Path to the video file for transcription")
    parser.add_argument("--model_size", default=DEFAULT_MODEL_SIZE, help="Whisper model size (e.g. tiny, base, small, medium, large-v3)")
    parser.add_argument("--device", default=DEFAULT_DEVICE, help="Device to use (cpu or cuda)")
    parser.add_argument("--task", default=DEFAULT_TASK, help="Task: transcribe or translate")
    parser.add_argument("--compute_type", default=DEFAULT_COMPUTE_TYPE, help="Compute type (float16, int8_float16, int8)")
    args = parser.parse_args()
    transcribe_video(args.input_file, args.model_size, args.device, args.task, args.compute_type)

if __name__ == "__main__":
    main()
