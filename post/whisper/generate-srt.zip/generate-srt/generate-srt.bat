:: Author: Wells @ wellstsai.com

@ECHO OFF
SETLOCAL EnableDelayedExpansion

:: 設定控制台編碼為 UTF-8
CHCP 65001 > NUL

:: ====================================================================
:: config 區段
:: ====================================================================
SET "whisperModel=base"                   :: tiny, base, small, medium, large-v3
SET "openEditor=code"                     :: none, notepad, code
SET "autoLoop=false"                      :: true, false
SET "whisperDevice=cpu"                   :: cuda, cpu
SET "whisperTask=transcribe"              :: transcribe, translate
SET "computeType=auto"                    :: auto, float16, float32, int8, int4
SET "pythonScriptName=generate-srt.py"    :: 轉寫腳本名稱
SET "outputDir=output"                    :: 轉寫結果輸出目錄
SET "ytdlpPath=%~dp0yt-dlp.exe"     
SET "luxPath=%~dp0lux.exe"      

:: ====================================================================
:: 環境檢查 (Pre-flight Check)
:: ====================================================================
ECHO 正在進行環境檢查...

SET "ytDlpFound=0"    & SET "luxFound=0"
SET "pythonFound=0"   & SET "scriptFound=0"
SET "fasterWhisperFound=0"
SET "downloaderFoundCount=0"

WHERE yt-dlp >NUL 2>NUL && (SET "ytDlpFound=1" & SET "ytdlpExec=yt-dlp") || (
    IF EXIST "%ytdlpPath%" (SET "ytDlpFound=1" & SET "ytdlpExec=%ytdlpPath%")
)
WHERE lux   >NUL 2>NUL && (SET "luxFound=1"   & SET "luxExec=lux")   || (
    IF EXIST "%luxPath%"   (SET "luxFound=1"   & SET "luxExec=%luxPath%")
)
WHERE python >NUL 2>NUL && (SET "pythonFound=1")

IF EXIST "%~dp0%pythonScriptName%" (SET "scriptFound=1")
IF %pythonFound% EQU 1 (
    python -c "import faster_whisper" >NUL 2>NUL && (SET "fasterWhisperFound=1")
)

IF %ytDlpFound% EQU 1 (
    ECHO [V] yt-dlp 已就緒 & SET /A downloaderFoundCount+=1
) ELSE (
    ECHO [^!] 未偵測到 yt-dlp
)
IF %luxFound% EQU 1 (
    ECHO [V] lux 已就緒    & SET /A downloaderFoundCount+=1
) ELSE (
    ECHO [^!] 未偵測到 lux
)
IF %pythonFound% EQU 1 (
    ECHO [V] Python 已就緒
) ELSE (
    ECHO [^!] 未偵測到 Python; 請安裝並加入 PATH
)
IF %scriptFound% EQU 1 (
    ECHO [V] 找到轉寫腳本 %pythonScriptName%
) ELSE (
    ECHO [^!] 找不到轉寫腳本 %pythonScriptName%
)
IF %fasterWhisperFound% EQU 1 (
    ECHO [V] faster_whisper 已安裝
) ELSE (
    ECHO [^!] 未安裝 faster_whisper; 請執行 pip install faster-whisper
)

IF %downloaderFoundCount% EQU 0 (
    ECHO.&ECHO [錯誤] 未偵測到任何下載器 & PAUSE & EXIT /B
)
IF %pythonFound% NEQ 1 (
    ECHO.&ECHO [錯誤] Python 環境未就緒 & PAUSE & EXIT /B
)
IF %scriptFound% NEQ 1 (
    ECHO.&ECHO [錯誤] 轉寫腳本遺失 & PAUSE & EXIT /B
)
IF %fasterWhisperFound% NEQ 1 (
    ECHO.&ECHO [錯誤] faster_whisper 函式庫不完整 & PAUSE & EXIT /B
)

ECHO 環境檢查通過
ECHO ====================================================================
ECHO.

IF NOT EXIST "%outputDir%" mkdir "%outputDir%"

:main_loop
SET "videoUrl="
SET "videoId="
SET "tmpId="
SET "useDownloader=yt-dlp"

SET /P "videoUrl=請輸入影片網址: "
IF "%videoUrl%"=="" (
    ECHO [^!] 請輸入有效的網址
    IF /I "%autoLoop%"=="true" (PAUSE & CLS & GOTO :main_loop) ELSE GOTO :end_script
)

ECHO %videoUrl% | FINDSTR /I "youtube.com" >NUL
IF %ERRORLEVEL% EQU 0 (
    FOR /F "tokens=2 delims==&" %%I IN ("%videoUrl%") DO SET "videoId=%%I"
    SET "useDownloader=yt-dlp"
)

ECHO %videoUrl% | FINDSTR /I "bilibili.com/video/" >NUL
IF %ERRORLEVEL% EQU 0 (
    FOR /F "tokens=4 delims=/" %%I IN ("%videoUrl%") DO SET "tmpId=%%I"
    FOR /F "delims=?&"     %%J IN ("!tmpId!")   DO SET "videoId=%%J"
    SET "useDownloader=lux"
)

FOR %%S IN ("%outputDir%\*%videoId%*.srt") DO (
    IF EXIST "%%~fS" (
        ECHO [資訊] 找到現有字幕：%%~fS
        IF /I "%openEditor%"=="notepad" (
            notepad "%%~fS"
        ) ELSE (
            CALL code "%%~fS"
        )
        GOTO :loop_continue
    )
)

FOR %%V IN ("%outputDir%\*%videoId%*.mp4") DO (
    IF EXIST "%%~fV" (
        ECHO [資訊] 找到現有影片：%%~fV
        ECHO --- 開始 Faster-Whisper 轉寫 ---
        python "%~dp0%pythonScriptName%" "%%~fV" --model_size %whisperModel% --device %whisperDevice% --task %whisperTask% --compute_type %computeType%
        IF EXIST "%%~dpnV.srt" (
            MOVE /Y "%%~dpnV.srt" "%outputDir%\" 
            IF /I "%openEditor%"=="notepad" (
                notepad "%outputDir%\%%~nV.srt"
            ) ELSE (
                CALL code "%outputDir%\%%~nV.srt"
            )
        ) ELSE (
            ECHO [^!] 轉寫完成但找不到字幕檔
        )
        GOTO :loop_continue
    )
)

IF /I "%useDownloader%"=="lux" (
    GOTO :lux_section
) ELSE (
    GOTO :yt_dlp_section
)

:yt_dlp_section
ECHO.
ECHO --- 使用 yt-dlp 下載 ---
"%ytdlpExec%" -f worst "%videoUrl%"

FOR /F "delims=" %%F IN ('dir *%videoId%*.mp4 /B 2^>NUL') DO (
    ECHO [成功] 下載完成: %%F
    ECHO [資訊] 使用預設檔名：%%~nF%%~xF
    ECHO.
    ECHO --- 開始 Faster-Whisper 轉寫 ---
    python "%~dp0%pythonScriptName%" "%%F" --model_size %whisperModel% --device %whisperDevice% --task %whisperTask% --compute_type %computeType%
    IF EXIST "%%~nF.srt" (
        MOVE /Y "%%F"         "%outputDir%\" 
        MOVE /Y "%%~nF.srt"   "%outputDir%\" 
        IF /I "%openEditor%"=="notepad" (
            notepad "%outputDir%\%%~nF.srt"
        ) ELSE (
            CALL code "%outputDir%\%%~nF.srt"
        )
    ) ELSE (
        ECHO [^!] 找不到字幕檔
    )
    GOTO :end_script
)
GOTO :end_script

:lux_section
ECHO.
ECHO --- 使用 lux 取得最低畫質 stream key ---
"%luxExec%" -j "%videoUrl%" > tmp_lux.json

FOR /F "usebackq tokens=*" %%K IN (`
    powershell -NoProfile -Command ^
      "(Get-Content 'tmp_lux.json' -Raw ^| ConvertFrom-Json).streams.PSObject.Properties ^| Sort-Object Value.size ^| Select-Object -First 1 -ExpandProperty Name"
`) DO SET "STREAM_ID=%%K"

DEL /F /Q tmp_lux.json

IF DEFINED STREAM_ID (
    ECHO [資訊] 已選擇最低畫質 stream：!STREAM_ID!
    "%luxExec%" -f "!STREAM_ID!" "%videoUrl%"
) ELSE (
    ECHO [^!] 未取得 stream ID，改用預設下載最高畫質...
    "%luxExec%" "%videoUrl%"
)

FOR /F "delims=" %%F IN ('dir /b /o-d *.mp4') DO (
    ECHO [成功] 下載完成: %%F
    SET "origName=%%~nF"
    SET "newName=!origName! [!videoId!]"
    REN "%%F"           "!newName!%%~xF"
    ECHO [資訊] 已將 %%F 重新命名為 !newName!%%~xF
    ECHO.
    ECHO --- 開始 Faster-Whisper 轉寫 ---
    python "%~dp0%pythonScriptName%" "!newName!%%~xF" --model_size %whisperModel% --device %whisperDevice% --task %whisperTask% --compute_type %computeType%
    IF EXIST "!newName!.srt" (
        MOVE /Y "!newName!%%~xF" "%outputDir%\" 
        MOVE /Y "!newName!.srt"    "%outputDir%\" 
        IF /I "%openEditor%"=="notepad" (
            notepad "%outputDir%\!newName!.srt"
        ) ELSE (
            CALL code "%outputDir%\!newName!.srt"
        )
    ) ELSE (
        ECHO [^!] 找不到字幕檔
    )
    GOTO :end_script
)
GOTO :end_script

:loop_continue
IF /I "%autoLoop%"=="true" (
    PAUSE & CLS & GOTO :main_loop
) ELSE (
    GOTO :end_script
)

:end_script
ECHO.&ECHO 程式結束 & PAUSE & EXIT /B
